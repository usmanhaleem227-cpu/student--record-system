# Student Record Management System

A beginner-friendly command-line project written in Rust. It manages student records using structs, vectors, functions, ownership/borrowing, pattern matching, error handling, modules, iterators, file handling, and tests.

## Features
- Add student
- Display all students
- Search by student ID
- Update student information
- Delete student
- Search by department
- Calculate/display grade and pass/fail result
- Save records to `students.txt`
- Load records from `students.txt`
- Basic automated tests

## Requirements
Install Rust and Cargo from the official Rust website.

## Run the project
Open a terminal inside this folder and run:

```text
cargo run
```

## Run tests

```text
cargo test
```

## Project structure

```text
student_record_system/
├── Cargo.toml
├── README.md
└── src/
    ├── main.rs
    ├── student.rs
    ├── menu.rs
    └── file_manager.rs
```

## Data file
When records are saved, the program creates `students.txt` in the project folder. You do not need to create it manually.
