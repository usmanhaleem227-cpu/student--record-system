use crate::student::Student;
use std::fs;
use std::io;

pub const FILE_NAME: &str = "students.txt";

pub fn save_students(students: &[Student]) -> io::Result<()> {
    let data = students
        .iter()
        .map(Student::to_file_line)
        .collect::<Vec<String>>()
        .join("\n");
    fs::write(FILE_NAME, data)
}

pub fn load_students() -> io::Result<Vec<Student>> {
    match fs::read_to_string(FILE_NAME) {
        Ok(data) => {
            let mut students = Vec::new();
            for (line_number, line) in data.lines().enumerate() {
                if line.trim().is_empty() {
                    continue;
                }
                match Student::from_file_line(line) {
                    Ok(student) => students.push(student),
                    Err(error) => eprintln!("Warning: could not read line {}: {}", line_number + 1, error),
                }
            }
            Ok(students)
        }
        Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(Vec::new()),
        Err(error) => Err(error),
    }
}
