use crate::student::Student;
use std::io::{self, Write};

fn input(prompt: &str) -> String {
    print!("{}", prompt);
    io::stdout().flush().expect("Could not flush output");
    let mut value = String::new();
    io::stdin().read_line(&mut value).expect("Could not read input");
    value.trim().to_string()
}

pub fn read_id() -> u32 {
    loop {
        match input("Enter Student ID: ").parse::<u32>() {
            Ok(id) => return id,
            Err(_) => println!("Please enter a valid numeric ID."),
        }
    }
}

fn read_semester() -> u8 {
    loop {
        match input("Enter Semester (1-8): ").parse::<u8>() {
            Ok(semester) if (1..=8).contains(&semester) => return semester,
            _ => println!("Please enter a semester from 1 to 8."),
        }
    }
}

fn read_marks() -> f32 {
    loop {
        match input("Enter Marks (0-100): ").parse::<f32>() {
            Ok(marks) if (0.0..=100.0).contains(&marks) => return marks,
            _ => println!("Please enter marks between 0 and 100."),
        }
    }
}

pub fn add_student(students: &mut Vec<Student>) {
    println!("\n--- Add Student ---");
    let id = read_id();
    if students.iter().any(|s| s.id == id) {
        println!("A student with this ID already exists.");
        return;
    }

    let name = input("Enter Name: ");
    let department = input("Enter Department: ");
    let semester = read_semester();
    let marks = read_marks();

    match Student::new(id, name, department, semester, marks) {
        Ok(student) => {
            students.push(student);
            println!("Student added successfully.");
        }
        Err(error) => println!("Could not add student: {}", error),
    }
}

pub fn display_students(students: &[Student]) {
    println!("\n--- All Students ---");
    if students.is_empty() {
        println!("No student records found.");
        return;
    }

    for student in students {
        print_student(student);
    }
}

pub fn search_student(students: &[Student]) {
    println!("\n--- Search Student ---");
    let id = read_id();
    match students.iter().find(|s| s.id == id) {
        Some(student) => print_student(student),
        None => println!("Student not found."),
    }
}

pub fn update_student(students: &mut [Student]) {
    println!("\n--- Update Student ---");
    let id = read_id();
    match students.iter_mut().find(|s| s.id == id) {
        Some(student) => {
            println!("Leave a field empty to keep its current value.");
            let name = input(&format!("Name [{}]: ", student.name));
            if !name.is_empty() { student.name = name; }

            let department = input(&format!("Department [{}]: ", student.department));
            if !department.is_empty() { student.department = department; }

            let semester = input(&format!("Semester [{}]: ", student.semester));
            if !semester.is_empty() {
                match semester.parse::<u8>() {
                    Ok(value) if (1..=8).contains(&value) => student.semester = value,
                    _ => println!("Invalid semester. Keeping old value."),
                }
            }

            let marks = input(&format!("Marks [{}]: ", student.marks));
            if !marks.is_empty() {
                match marks.parse::<f32>() {
                    Ok(value) if (0.0..=100.0).contains(&value) => student.marks = value,
                    _ => println!("Invalid marks. Keeping old value."),
                }
            }
            println!("Student updated successfully.");
        }
        None => println!("Student not found."),
    }
}

pub fn delete_student(students: &mut Vec<Student>) {
    println!("\n--- Delete Student ---");
    let id = read_id();
    if let Some(index) = students.iter().position(|s| s.id == id) {
        students.remove(index);
        println!("Student deleted successfully.");
    } else {
        println!("Student not found.");
    }
}

pub fn search_by_department(students: &[Student]) {
    println!("\n--- Search by Department ---");
    let department = input("Enter Department: ");
    let matches: Vec<&Student> = students
        .iter()
        .filter(|s| s.department.eq_ignore_ascii_case(&department))
        .collect();

    if matches.is_empty() {
        println!("No students found in this department.");
    } else {
        for student in matches { print_student(student); }
    }
}

pub fn show_result(students: &[Student]) {
    println!("\n--- Student Result ---");
    let id = read_id();
    match students.iter().find(|s| s.id == id) {
        Some(student) => {
            println!("Name: {}", student.name);
            println!("Marks: {:.2}", student.marks);
            println!("Grade: {}", student.grade());
            println!("Status: {}", if student.is_pass() { "PASS" } else { "FAIL" });
        }
        None => println!("Student not found."),
    }
}

fn print_student(student: &Student) {
    println!("------------------------------");
    println!("ID: {}", student.id);
    println!("Name: {}", student.name);
    println!("Department: {}", student.department);
    println!("Semester: {}", student.semester);
    println!("Marks: {:.2}", student.marks);
    println!("Grade: {}", student.grade());
    println!("Status: {}", if student.is_pass() { "PASS" } else { "FAIL" });
}

pub fn menu_choice() -> String {
    println!("\n================================");
    println!("     STUDENT RECORD SYSTEM");
    println!("================================");
    println!("1. Add Student");
    println!("2. Display Students");
    println!("3. Search Student");
    println!("4. Update Student");
    println!("5. Delete Student");
    println!("6. Search by Department");
    println!("7. Show Result");
    println!("8. Save Records");
    println!("9. Load Records");
    println!("0. Exit");
    input("Enter your choice: ")
}
