#[derive(Debug, Clone)]
pub struct Student {
    pub id: u32,
    pub name: String,
    pub department: String,
    pub semester: u8,
    pub marks: f32,
}

impl Student {
    pub fn new(id: u32, name: String, department: String, semester: u8, marks: f32) -> Result<Self, String> {
        if !(0.0..=100.0).contains(&marks) {
            return Err("Marks must be between 0 and 100.".to_string());
        }
        if semester == 0 || semester > 8 {
            return Err("Semester must be between 1 and 8.".to_string());
        }
        if name.trim().is_empty() {
            return Err("Name cannot be empty.".to_string());
        }
        if department.trim().is_empty() {
            return Err("Department cannot be empty.".to_string());
        }

        Ok(Self { id, name, department, semester, marks })
    }

    pub fn grade(&self) -> &'static str {
        if self.marks >= 90.0 {
            "A+"
        } else if self.marks >= 80.0 {
            "A"
        } else if self.marks >= 70.0 {
            "B+"
        } else if self.marks >= 60.0 {
            "B"
        } else if self.marks >= 50.0 {
            "C"
        } else if self.marks >= 40.0 {
            "D"
        } else {
            "F"
        }
    }

    pub fn is_pass(&self) -> bool {
        self.marks >= 40.0
    }

    pub fn to_file_line(&self) -> String {
        format!("{}|{}|{}|{}|{}", self.id, self.name, self.department, self.semester, self.marks)
    }

    pub fn from_file_line(line: &str) -> Result<Self, String> {
        let parts: Vec<&str> = line.split('|').collect();
        if parts.len() != 5 {
            return Err("Invalid record format.".to_string());
        }

        let id = parts[0].parse::<u32>().map_err(|_| "Invalid student ID.".to_string())?;
        let semester = parts[3].parse::<u8>().map_err(|_| "Invalid semester.".to_string())?;
        let marks = parts[4].parse::<f32>().map_err(|_| "Invalid marks.".to_string())?;

        Self::new(id, parts[1].to_string(), parts[2].to_string(), semester, marks)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn grade_is_calculated_correctly() {
        let student = Student::new(1, "Ali".into(), "CS".into(), 4, 78.0).unwrap();
        assert_eq!(student.grade(), "B+");
    }

    #[test]
    fn invalid_marks_are_rejected() {
        let result = Student::new(1, "Ali".into(), "CS".into(), 4, 120.0);
        assert!(result.is_err());
    }
}
