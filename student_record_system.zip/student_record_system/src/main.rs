mod file_manager;
mod menu;
mod student;

use std::io;

fn main() {
    let mut students = match file_manager::load_students() {
        Ok(records) => {
            if !records.is_empty() {
                println!("Loaded {} student record(s) from {}.", records.len(), file_manager::FILE_NAME);
            }
            records
        }
        Err(error) => {
            println!("Could not load records: {}", error);
            Vec::new()
        }
    };

    loop {
        match menu::menu_choice().as_str() {
            "1" => menu::add_student(&mut students),
            "2" => menu::display_students(&students),
            "3" => menu::search_student(&students),
            "4" => menu::update_student(&mut students),
            "5" => menu::delete_student(&mut students),
            "6" => menu::search_by_department(&students),
            "7" => menu::show_result(&students),
            "8" => match file_manager::save_students(&students) {
                Ok(_) => println!("Records saved successfully to {}.", file_manager::FILE_NAME),
                Err(error) => println!("Could not save records: {}", error),
            },
            "9" => match file_manager::load_students() {
                Ok(records) => {
                    students = records;
                    println!("Records loaded successfully.");
                }
                Err(error) => println!("Could not load records: {}", error),
            },
            "0" => {
                println!("Do you want to save before exiting? (y/n)");
                let mut answer = String::new();
                io::stdin().read_line(&mut answer).expect("Could not read input");
                if answer.trim().eq_ignore_ascii_case("y") {
                    match file_manager::save_students(&students) {
                        Ok(_) => println!("Records saved."),
                        Err(error) => println!("Could not save records: {}", error),
                    }
                }
                println!("Thank you for using Student Record System!");
                break;
            }
            _ => println!("Invalid choice. Please select a number from 0 to 9."),
        }
    }
}
